# SYP_SistemaColegio
 Sistema de aplicacion de gestion general de un colegio ncorporando base de datos remota
